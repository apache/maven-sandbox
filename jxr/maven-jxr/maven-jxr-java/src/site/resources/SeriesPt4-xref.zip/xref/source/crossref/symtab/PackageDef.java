
package com.magelang.xref.symtab;

/*******************************************************************************
 * Definition of a package. 
 ******************************************************************************/
class PackageDef extends ScopedDef       
{
    //==========================================================================
    //==  Methods
    //==========================================================================
    

    /** Constructor to create a package object */
    PackageDef(String name,                // the name of the package
               Occurrence occ,             // where it was defined (NULL)
               ScopedDef parentScope) {    // which scope owns it
        super(name, occ, parentScope);
    }   


    /** Write information about this package to the report */
    public void report(IndentingPrintWriter out) {
        // write the package name
        out.println("Package: " + getQualifiedName());
        out.println("-----------------------------------------");
        out.indent();
        
        // list all references to this package (in import statements)
        listReferences(out);
        
        // if we found any definitions in this package, report them
        if (hasElements())
            reportElements(out);
        else
            out.println("(No definitions parsed)");
        out.dedent();
        out.println();
    }   
}