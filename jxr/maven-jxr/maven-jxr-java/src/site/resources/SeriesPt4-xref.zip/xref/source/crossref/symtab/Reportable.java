
package com.magelang.xref.symtab;

/*******************************************************************************
 * This interface is used as a handle to all classes that can be reported 
 ******************************************************************************/
interface Reportable {

    /** Write information about an object to the cross-reference report */
    void report(IndentingPrintWriter out);
}